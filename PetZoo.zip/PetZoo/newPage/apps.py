from django.apps import AppConfig

class NewpageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'newPage'