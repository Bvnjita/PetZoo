from django.contrib import admin
from .models import tipoUsuario, Usuario

admin.site.register(tipoUsuario)
admin.site.register(Usuario)