from django.urls import path
from . import views

urlpatterns = [
    path("index", views.index, name="index"),
    path("login", views.login, name="login"),
    path("accesorios", views.accesorios, name="accesorios"),
    path("comida", views.comida, name="comida"),
    path("farmacia", views.farmacia, name="farmacia"),
    path("register", views.register, name="Register"),
    path("inicio", views.agregar, name="inicio"),
    path("tipo_login", views.tipo_login, name="tipologin"),
    path("user_edit", views.user_edit, name="user_edit"),
    path("despachos", views.despachos, name="despachos"),
    path("agregar", views.agregar, name="agregar"),
    path("editar", views.tipo_edit, name="editar"),
    

]